Install on Mac OS 10.5 Leopard:
* Doubleclick install.term (with an administrative account) to install BlackHoleHunter on a local Mac OS X 10.5 system (Leopard). Files and directories in /etc/apache2 and /Library/WebServer will be replaced, the originals will get appended the extension .bhhbak to allow for later uninstall.
* Check "Web Sharing" is enabled in "System Preference" -> "Sharing".

Uninstall on MacOS X;
* Doubleclick uninstall.term

Install on Linux:
* blackholehunter.apache2.site is an apache site config for a BHH installed (e.g. on a Linux system) in /var/blackholehunter/public_html

