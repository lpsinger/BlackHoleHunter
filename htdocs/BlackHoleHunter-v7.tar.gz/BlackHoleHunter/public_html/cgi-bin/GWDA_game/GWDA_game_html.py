#!/usr/bin/env python
import random

def html_header_standard():
  htmlOutput = html_header_top() + html_header_bottom()
  return htmlOutput


def html_header_flash(waveSound,signalSound):
  htmlOutput = html_header_top() + html_header_flashscript(waveSound,signalSound) + html_header_bottom()
  return htmlOutput

def html_header_top():
  htmlOutput = """<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
<head>
	<meta name="Author" content="Cardiff University Relativity Group"/>
	<meta name="copyright" content="Copyright Cardiff University"/>
	<meta name="Description" content="Black Hole Hunter Website "/>
	<meta name="keywords" content="Black Hole Hunter, Relativity Group, Cardiff University, Cardiff, Wales, United Kingdom"/>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Black Hole Hunter</title>
	<style type="text/css" media="all"> @import "/styles-site.css"; </style>
	<link rel="alternate stylesheet" type="text/css" media="all" title="large" href="/large.css"/>
	<link rel="alternate stylesheet" type="text/css" media="all" title="small" href="/small.css"/>
	<link rel="stylesheet" type="text/css" media="all" href="/css/yui/container.css"/>
	<script type="text/javascript" src="/scripts/styleswitcher.js"></script>
	<script type="text/javascript" src="/scripts/popup.js"></script>
	<script src="/js/yui/yahoo-dom-event.js" type="text/javascript"></script>
    <script src="/js/yui/dragdrop-min.js" type="text/javascript"></script>
    <script src="/js/yui/container-min.js" type="text/javascript"></script>
    <script src="/js/yui/popups.js" type="text/javascript"></script>
"""
  return htmlOutput


def html_header_bottom():
  htmlOutput = """</head>

<body>
<div id="wrap">
	<div id="header">
		<span><a href="http://localhost/"><img src="/images/logo2.jpg" alt="Black Hole Hunter" title="Black Hole Hunter" height="62" width="452" /></a></span>
		<div id="right">
			Schriftgr&ouml;&szlig;e: 
			<a href="#" onclick="setActiveStyleSheet('small'); return false;">Klein</a>
			 / 
			<a href="#" onclick="setActiveStyleSheet('medium'); return false;">Normal</a>
			 / 
			<a href="#" onclick="setActiveStyleSheet('large'); return false;">Gro&szlig;</a>
			<br />
			<a href="http://localhost/start.html">Spiel verlassen</a>
<!--
			<br/>
			<a href="http://jigsaw.w3.org/css-validator/validator?uri=http://www.blackholehunter.org/" rel="external"><img style="border:0;width:80px;height:15px" src="/images/css.gif" alt="Valid CSS!" title="Valid CSS!"/></a>
			<a href="http://validator.w3.org/check?uri=referer" rel="external"><img src="/images/xhtml0.gif" alt="Valid XHTML 1.0" title="Valid XHTML 1.0" height="15" width="80" /></a>
-->
		</div>
	</div>
"""
  return htmlOutput

def html_header_flashscript(waveSound,signalSound):
  htmlOutput = """	<script type="text/javascript" src="/soundmanager/script/soundmanager2-nodebug-jsmin.js"></script>
	<script type="text/javascript">
		soundManager.url = '/soundmanager/soundmanager2.swf'; // override default SWF url
		soundManager.debugMode = true;
		soundManager.consoleOnly = false;
		soundManager.onload = function() {
//			soundManager is initialised, ready to use. Create a sound for this demo page.
			soundManager.createSound({
				id:'signal',
				url: '""" + signalSound + """'
			});
			soundManager.createSound({
				id:'sound0',
				url: '""" + waveSound[0] + """'
			});
			soundManager.createSound({
				id:'sound1',
				url: '""" + waveSound[1] + """'
			});
			soundManager.createSound({
				id:'sound2',
				url: '""" + waveSound[2] + """'
			});
			soundManager.createSound({
				id:'sound3',
				url: '""" + waveSound[3] + """'
			});
			soundManager.createSound({
				id:'chirp',
				url: '/eo/chirp1.mp3'
			});
			soundManager.createSound({
				id:'BHNS',
				url: '/eo/BHNS.mp3'
			});
			soundManager.createSound({
				id:'GEO',
				url: '/eo/GEO.mp3'
			});
		}
	</script>
"""
  return htmlOutput

def error_form_reading():
  htmlOutput = """<div id="contentgame"> 
<p>
Fehler beim Verarbeiten der Formulardaten. Bitte kehren Sie zur vorigen Seite zur&uuml;ck und probieren Sie es nochmal.
</p>
<form action="/index.html" method="post">
<p>
<input name="submit" value="Nochmal" id="submit" type="submit"/>
</p>
</form> 
</div>
</div>
</body>

</html>
"""
  return htmlOutput

def no_signal_set():
  htmlOutput = """<div id="contentgame"> /n"""
  htmlOutput += "Fehler: Es wurde kein signal ausgew&auml;hlt. Wenn Sie diese Nachricht sehen, kontaktieren Sie bitte die Entwickler des Spiels.\n"
  htmlOutput +=  "Bitte kehren Sie zur vorigen Seite zur&uuml;ck und probieren Sie es nochmal.\n"
  htmlOutput += """<form method="post" action="/index.html">
<p>
<input type="submit" value="Nochmal." />
</p>
</form> \n"""
  htmlOutput += "</div></div></body></html \n>"
  return htmlOutput

def game_main_html(numBoxes,waveSound,wavePicture,signalSound,signalPicture, \
                   sigNoisePicture,signalType,signalMass1,\
                   signalMass2,signalInclination,\
                   signalLocation,userScore,difficultyLevel,glitchFlag,\
                   numPlays,numLives):
  htmlOutput = """<div id="contentgame">"""
  htmlOutput += """<p class="intro" style="border-right: 1px solid #000000">\n"""
  htmlOutput += "Sie haben bei dieser Mission die Aufgabe, das durch die Verschmelzung"
  if float(signalMass1) > 3 and float(signalMass2) > 3:
    htmlOutput += """ zweier schwarzer L&ouml;cher"""
  elif float(signalMass1) < 3 and float(signalMass2) < 3:
    htmlOutput += """ zweier Neutronensterne"""
  else:
    htmlOutput += """ eines Schwarzen Loches und eines Neutronensternes"""
  htmlOutput += " mit " + signalMass2 + " und " + signalMass1
  htmlOutput += """ Sonnenmassen entstehende Gravitationswellensignal 
  in den verrauschten Daten eines Gravitationswellendetektors zu finden.\n"""
  htmlOutput += "</p>\n<p class=\"intro\">\n"
  htmlOutput += "Sie k&ouml;nnen das Ausgangssignal h&ouml;ren, indem Sie auf die untenstehenden Bilder klicken. Dann sehen und h&ouml;ren Sie sich die vier Datens&auml;tze des Detektors an. Entscheiden Sie, welcher davon das Signal enth&auml;lt!\n"
  htmlOutput += "</p>\n\n"


  if glitchFlag:
    htmlOutput += """<p class="warning">
<b>Achtung!</b><br/>
Die Detektoren geben in der Realit&auml;t keine perfekten Daten aus. 
Einige der Datens&auml;tze k&ouml;nnen kurze St&ouml;rger&auml;usche enthalten. 
Lassen Sie sich davon nicht t&auml;uschen!
</p>
\n
"""


  htmlOutput += """<br style="clear: both" />\n\n"""
  htmlOutput += """<div class="signal"> \n"""
  htmlOutput +="<p><b>Klicken Sie auf das untenstehende Bild, um den Ton zu h&ouml;ren.</b></p>\n\n"

  htmlOutput += """<img onclick="soundManager.play('signal')" style="width: 380px; height: 274px;" src=" """ + signalPicture  + """ " alt="Das gesuchte Signal" title="Das gesuchte Signal"/>\n"""  
  htmlOutput +="<p><b>Dieses Gravitationswellensignal suchen Sie.</b></p>\n"
  htmlOutput +="""<br />\n"""

  if float(signalMass1) > 3 and float(signalMass2) > 3:
    signalPiccy = random.randrange(0,3,1)
    if signalPiccy == 0:
      htmlOutput +="""<img onclick="soundManager.play('signal')" style="width: 263px; height: 274px;" src="/images/bbh.jpg" alt="Ein Doppelsternsystem aus zwei schwarzen L&ouml;chern" title="A binary black hole system"/>\n"""
    if signalPiccy == 1:
      htmlOutput +="""<img onclick="soundManager.play('signal')" style="width: 365px; height: 274px;" src="/images/ORBHOLE7.jpg" alt="A binary black hole system." title="A binary black hole system"/>\n"""
    if signalPiccy == 2:
      htmlOutput +="""<img onclick="soundManager.play('signal')" style="width: 368px; height: 274px;" src="/images/bhCoal1.gif" alt="A binary black hole system." title="A binary black hole system"/>\n"""
  elif float(signalMass1) < 3 and float(signalMass2) < 3:
    signalPiccy = random.randrange(0,2,1)
    if signalPiccy == 0:
      htmlOutput +="""<img onclick="soundManager.play('signal')" style="width: 343px; height: 274px;" src="/images/bns.jpg" alt="A binary neutron star system." title="A binary neutron star system."/>\n"""
    if signalPiccy == 1:
      htmlOutput +="""<img onclick="soundManager.play('signal')" style="width: 365px; height: 274px;" src="/images/still1.jpg" alt="A binary neutron star system." title="A binary neutron star system."/>\n"""
  else:
    signalPiccy = random.randrange(0,2,1)
    if signalPiccy == 0:
      htmlOutput +="""<img onclick="soundManager.play('signal')" style="width: 281px; height: 274px;" src="/images/nsbh.jpeg " alt="A neutron star, black hole system." title="A neutron star, black hole system" />\n"""
    if signalPiccy == 1:
      htmlOutput +="""<img onclick="soundManager.play('signal')" style="width: 292px; height: 274px;" src="/images/Neutron4Lunch_1.jpg " alt="A neutron star, black hole system." title="A neutron star, black hole system" />\n"""


  htmlOutput +="<p><b>Diese Wellenform h&ouml;ren Sie.</b></p>\n"
  htmlOutput +="</div>\n\n"

  htmlOutput += """<div class = "outputs">\n"""
  htmlOutput += "<p><b>Klicken Sie auf die einzelnen Bilder, um den zugeh&ouml;rigen Ton zu h&ouml;ren.</b></p> \n"
  htmlOutput += """<div id="stream1">\n"""
  htmlOutput += """<img onclick="soundManager.play('sound0')" style="width: 380px; height: 274px;" src=" """ + wavePicture[0] + """ " alt="Is the signal in here?" title="Is the signal in here?" />\n"""
  htmlOutput += "<p><b>Datensatz 1</b></p>\n"
  htmlOutput += "</div>\n"
  htmlOutput += """<div id="stream2">\n"""
  htmlOutput += """<img onclick="soundManager.play('sound1')" style="width: 380px; height: 274px;" src=" """ + wavePicture[1] + """ " alt="Is the signal in here?" title="Is the signal in here?" />\n"""
  htmlOutput += "<p><b>Datensatz 2</b></p>\n"
  htmlOutput += "</div>\n"
  htmlOutput += """<div id="stream3">\n"""
  htmlOutput += """<img onclick="soundManager.play('sound2')" style="width: 380px; height: 274px;" src=" """ + wavePicture[2] + """ " alt="Is the signal in here?" title="Is the signal in here?" />\n"""
  htmlOutput += "<p><b>Datensatz 3</b></p>\n"
  htmlOutput += "</div>\n"
  htmlOutput += """<div id="stream4">\n"""
  htmlOutput += """<img onclick="soundManager.play('sound3')" style="width: 380px; height: 274px;" src=" """ + wavePicture[3] + """ " alt="Is the signal in here?" title="Is the signal in here?" />\n"""
  htmlOutput += "<p><b>Datensatz 4</b></p>\n"
  htmlOutput += "</div>"


  htmlOutput += """<div id="select">\n"""
  htmlOutput += """<form method="post" action="/cgi-bin/GWDA_game/GWDA_game02.py">\n"""
  htmlOutput += """<p>W&auml;hlen Sie aus, welcher Datensatz das Signal enth&auml;lt:&nbsp;&nbsp;\n"""
  htmlOutput += """<input name="submit" value="Weiter" id="submit" type="submit"/><br/></p> \n"""  
  htmlOutput += """<p><input name="answer" id="answer" value="1" type="radio" checked="checked"/>Datensatz 1 \n"""
  htmlOutput += """&nbsp;&nbsp;&nbsp;&nbsp; \n"""
  htmlOutput += """<input name="answer" value="2" type="radio"/>Datensatz 2 \n"""
  htmlOutput += """&nbsp;&nbsp;&nbsp;&nbsp; \n"""
  htmlOutput += """&nbsp;&nbsp;&nbsp;&nbsp; <br/> \n"""
  htmlOutput += """<input name="answer" value="3" type="radio"/>Datensatz 3 \n"""
  htmlOutput += """&nbsp;&nbsp;&nbsp;&nbsp; \n"""  
  htmlOutput += """<input name="answer" value="4" type="radio"/>Datensatz 4 \n"""  

  htmlOutput += """<input type="hidden" name="asfdghti" value=""" + "\""  + str(signalLocation) + "\"" + """/>
<input type="hidden" name="userscore" value=" """ + str(userScore) + """ "/>
<input type="hidden" name="difficulty" value=" """ + str(difficultyLevel) + """ "/>
<input type="hidden" name="numplays" value=" """ + str(numPlays) + """ "/>
<input type="hidden" name="numlives" value=" """ + str(numLives) + """ "/>
<input type="hidden" name="signalpic" value=" """ + sigNoisePicture + """ "/>
<input type="hidden" name="wavepic1" value=" """ + wavePicture[0] + """ "/>
<input type="hidden" name="wavepic2" value=" """ + wavePicture[1] + """ "/>
<input type="hidden" name="wavepic3" value=" """ + wavePicture[2] + """ "/>
<input type="hidden" name="wavepic4" value=" """ + wavePicture[3] + """ "/>
<input type="hidden" name="wavesound1" value=" """ + waveSound[0] + """ "/>
<input type="hidden" name="wavesound2" value=" """ + waveSound[1] + """ "/>
<input type="hidden" name="wavesound3" value=" """ + waveSound[2] + """ "/>
<input type="hidden" name="wavesound4" value=" """ + waveSound[3] + """ "/>   
"""
  htmlOutput += "<br />\n</p>\n</form>\n</div>\n</div>\n</div>\n</div>\n</body>\n</html>"""
  return htmlOutput

def answer_given(answerCorrect,wavePicture,userScore,quoteText,quoteLink,quoteID,quoteDivId,quoteSrc,quoteHd,\
                 difficultyLevel,numPlays,numLives):
  htmlOutput = """	<div id="contentgame"> \n"""
  htmlOutput += """<div id="result">\n"""

  if answerCorrect:
    htmlOutput += "<p><b>Gut gemacht!</b></p>\n"
  if not answerCorrect:
    htmlOutput += "<p><b>Schade!</b></p>\n"
  if answerCorrect:
    htmlOutput += "<p>Die Antwort ist korrekt!</p>\n"
  if not answerCorrect:
    htmlOutput += "<p>Die Antwort ist leider falsch.</p>\n"
  htmlOutput += """<p><b>Punkte: """ + str(userScore) + """&nbsp;&nbsp;&nbsp;&nbsp; Weitere Versuche: """ + str(numLives) + """</b></p>\n"""
  htmlOutput += """<form method="post" action="/cgi-bin/GWDA_game/GWDA_game01.py"> \n"""
  htmlOutput += """<p>\n"""
  htmlOutput += """<input type="hidden" name="quotetext" value=""" + "\"" + str(quoteText) + "\"" + """ />\n"""
  htmlOutput += """<input type="hidden" name="quotelink" value=""" + "\"" + str(quoteLink) + "\"" + """ />\n"""
  htmlOutput += """<input type="hidden" name="userscore" value=""" + "\"" + str(userScore) + "\"" + """ />
<input type="hidden" name="difficulty" value=""" + "\"" + str(difficultyLevel) + "\"" + """ />
<input type="hidden" name="numplays" value=""" + "\"" + str(numPlays) + "\"" + """ />
<input type="hidden" name="numlives" value=""" + "\"" + str(numLives) + "\"" + """ />
"""
  if numLives < 1:
    htmlOutput += """<input type="submit" value="Zu Ihrem Endergebnis "/>\n"""
  elif numPlays > 5:
    htmlOutput += """<input type="submit" value="Zu Ihrem Endergebnis "/>\n"""
  elif answerCorrect:
    htmlOutput += """<input type="submit" value="Weiter zu Level """ + str(difficultyLevel) + """ "/>\n"""
  else:
    htmlOutput += """<input type="submit" value="Level """ + str(difficultyLevel) + """ wiederholen"/>\n"""
  
  htmlOutput += "</p>\n"
  htmlOutput += """</form>\n<br />\n"""

  htmlOutput +="""<div class="didyouknow">
<p><b>Schon gewusst?</b></p>
<p>
""" + quoteText + """
</p>
"""
  if quoteLink:
    htmlOutput +="""
        <script type="text/javascript">
    	function """ + quoteDivId + """Insert() {
    		var req = new XMLHttpRequest();
    		req.open("GET",""" + '"' + quoteSrc + '"' + """,true);
    		req.onreadystatechange = function() {
    			if(req.readyState==4) {
    				if(req.status==200) {
    					var d = document.getElementById(""" + '"' + quoteDivId + """Body")
    					d.innerHTML = req.responseText;
    				}
    			}
    		}
    		req.send(null);
    	}
    </script>"""
    htmlOutput += """<p>\n<a href="javascript:""" + quoteDivId + 'Insert()"' + """id="quote""" + quoteID + """" title="Mehr lesen" rel="external">Mehr lesen ...</a>\n</p>\n</div>\n"""
    htmlOutput += """<div class="yui-skin-sam">
<div id=""" + '"' + quoteDivId + '"' + """>
<div class="hd">""" + quoteHd + """</div>
<div class="bd" id=""" + '"' + quoteDivId + 'Body"' + """></div>
<div class="ft">&copy; http://www.einstein-online.info</div>
</div>
"""

  htmlOutput += """</div>\n</div>\n"""
  htmlOutput += """<div class="outputs" style="border: none; padding-top: 20px">\n"""
  htmlOutput += """<div id="stream1">\n"""
  htmlOutput += """<img onclick="soundManager.play('sound0')" style="width: 380px; height: 274px;" src=" """ + wavePicture[0] + """ " alt="Data with signal (if present) shown." title="Data with signal (if present) shown." />\n"""
  htmlOutput += """<p><b>Datensatz 1</b></p>\n"""
  htmlOutput += """</div>\n"""
  htmlOutput += """<div id="stream2">\n"""
  htmlOutput += """<img onclick="soundManager.play('sound1')" style="width: 380px; height: 274px;" src=" """ + wavePicture[1] + """ " alt="Data with signal (if present) shown." title="Data with signal (if present) shown."/>\n"""
  htmlOutput += """<p><b>Datensatz 2</b></p>\n"""
  htmlOutput += """</div>\n"""
  htmlOutput += """<div id="stream3">\n"""
  htmlOutput += """<img onclick="soundManager.play('sound2')" style="width: 380px; height: 274px;" src=" """ + wavePicture[2] + """ " alt="Data with signal (if present) shown." title="Data with signal (if present) shown."/>\n"""
  htmlOutput += """<p><b>Datensatz 3</b></p>\n"""
  htmlOutput += """</div>\n"""
  htmlOutput += """<div id="stream4">\n"""
  htmlOutput += """<img onclick="soundManager.play('sound3')" style="width: 380px; height: 274px;" src=" """ + wavePicture[3] + """ " alt="Data with signal (if present) shown." title="Data with signal (if present) shown."/>\n"""
  htmlOutput += """<p><b>Datensatz 4</b></p>\n"""
  htmlOutput += """</div>\n"""
  htmlOutput += """</div>\n</div>\n</div>\n</body>\n</html>"""
  return htmlOutput

def game_over(finishFlag,userScore):
  htmlOutput ="""<div id="sidelinks">

<ul id="sidelist">

<li>Interesting Links:</li>
<li><a href="javascript:gravWellenInsert()" id="show1">Gravitationswellen f&uuml;r Einsteiger</a></li>
<li><a href="javascript:GW_WellenInsert()" id="show2">Die Wellennatur der Gravitationswellen</a></li>
<li><a href="javascript:zirpenInsert()" id="show3">Das Zirpen der Neutronensterne</a></li>
<li><a href="javascript:eahInsert()" id="show4">Einstein&#64;Home auf Einstein Online</a></li>
<li><hr/></li>

<li>
Black Hole Hunter game was developed as a part of the Royal Society
Summer Exhibition 2008, <i>Can you hear black holes collide?</i>
presented by Cardiff University, Universities of Birmingham, Glasgow
and Southampton in the UK in collaboration with the Albert Einstein
Institute and Milde Marketing in Germany.<br/>
<br/>
Copyright &copy; Cardiff University
</li>

<li><hr/></li>

<li>
<img src="/images/logos2go/GWDA_logos_vert_final.jpg" alt="" title="" height="392" width="222" id="maps" usemap="#links" />
</li>

</ul>
</div>
"""
  htmlOutput += """<div id="content"> \n"""
  htmlOutput += """<p>
<img class="float" title="Two merging black holes" src="/images/main_wav2.jpg" width="200" height="209" alt="Two merging black holes"/>
</p> \n"""
  htmlOutput += """<p>"""
  if finishFlag:
    htmlOutput += """<b> Herzlichen Gl&uuml;ckwunsch! </b></p> \n <p> Sie haben <i>Black Hole Hunter</i> erfolgreich zu Ende gespielt. Wir hoffen, es hat Ihnen Spa&szlig; gemacht!</p>"""
  else:
  	htmlOutput += """<b> Game Over! </b></p> \n <p>\n Sie haben alle Versuche aufgebraucht!<br/>Wir hoffen, dass Ihnen <i>Black Hole Hunter</i> Spa&szlig; gemacht hat.\n</p>\n<p>\n</p>"""
  	htmlOutput += """<p><b> Ihr Endergebnis: """ + str(userScore) + """</b></p>"""
  if finishFlag:
    htmlOutput += """<p> Wollen Sie es mit einem schwierigeren Einstiegslevel versuchen? </p>"""
  else:
    htmlOutput += """<p> Sie k&ouml;nnen es erneut versuchen: </p>"""
  htmlOutput += """
<form method="post" action="/index.html">
<p> <input type="submit" value="Neustart / Ende"/>
</p>
</form>
<div class="yui-skin-sam">
	<div id="gravWellen">
		<div class="hd">Was sind Gravitationswellen?</div>
		<div class="bd" id="gravWellenBody"></div>
		<div class="ft">&copy; http://www.einstein-online.info</div>
	</div>
	<div id="GW_Wellen">
		<div class="hd">Die Wellennatur der Gravitationswellen</div>
		<div class="bd" id="GW_WellenBody"></div>
		<div class="ft">&copy; http://www.einstein-online.info</div>
	</div>
	<div id="ZirpenNeutronensterne">
		<div class="hd">Das Zirpen der Neutronensterne</div>
		<div class="bd" id="zirpenBody"></div>
		<div class="ft">&copy; http://www.einstein-online.info</div>
	</div>
	<div id="eah">
		<div class="hd">Einstein@Home - Gravitationswellenjagd f&uuml;r alle</div>
		<div class="bd" id="eahBody"></div>
		<div class="ft">&copy; http://www.einstein-online.info</div>
	</div>
</div>

</div>
</div>
</div>
</div>
</body>

</html>
"""
  return htmlOutput 


