if (navigator.userAgent.indexOf("MSIE")){
document.write("<link rel=\"stylesheet\" type=\"text\/css\" media=\"all\" title=\"small\" href=\"\/small.css\"/>");
}
var cookie = readCookie("style");
