<script language="javascript">
<!--
if (navigator.userAgent.indexOf("Mac") && navigator.userAgent.
indexOf("MSIE")) {
document.write("<link rel=stylesheet href=\"styles\/mac_ie.css\" type=\"text\/css\">");
}
else if (navigator.userAgent.indexOf("Win") && navigator.userAgent.
indexOf("MSIE")) {
document.write("<link rel=stylesheet href=\"styles\/pc_ie.css\" type=\"text\/css\">");
}
else {
document.write("<link rel=stylesheet href=\"styles\/default.css\" type=\"text\/css\">");
} // -->
</script>
